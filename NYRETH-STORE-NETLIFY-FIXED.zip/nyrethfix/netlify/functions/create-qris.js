const https = require('https');
const STORE_KEY = process.env.NASIONALPAY_STORE_KEY || 'SK_fe4c8a1233f8456c33d1bb0d799674e7d29e645f874bae227b75edead0';
const API = 'https://merchant.nasionalpay.com/api/payment/generate';
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405,{ok:false,error:'Method Not Allowed'});
  try {
    const body = JSON.parse(event.body || '{}');
    const amount = Math.round(Number(body.amount));
    if (!Number.isFinite(amount) || amount < 1) return json(400,{ok:false,error:'Invalid amount'});
    const upstream = await post(API,{key:STORE_KEY,channel:'QRIS',amount,player_username:String(body.player_username||'NYRETH-STORE')});
    if (!upstream.ok) return json(upstream.httpStatus,{ok:false,error:upstream.error||'NasionalPay error',data:upstream.data});
    const d=upstream.data||{};
    return json(200,{ok:d.status!==false,transaction_id:d.transaction_id||d.trx_id||d.data?.transaction_id||d.data?.trx_id||null,trx_id:d.trx_id||d.transaction_id||null,qris_data:d.qris_data||d.data?.qris_data||null,qris_image:d.qris_image||d.data?.qris_image||null,expired_at:d.expired_at||d.data?.expired_at||null,data:d});
  } catch(e){ return json(500,{ok:false,error:e.message}); }
};
function post(url,payload){return new Promise((resolve)=>{const u=new URL(url);const req=https.request({hostname:u.hostname,path:u.pathname,method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'}},res=>{let s='';res.on('data',c=>s+=c);res.on('end',()=>{let data;try{data=JSON.parse(s)}catch{data=null}resolve({httpStatus:res.statusCode,ok:res.statusCode>=200&&res.statusCode<300&&!!data,error:data?.message||data?.error||(!data?'Empty/non-JSON response':null),data})})});req.on('error',e=>resolve({httpStatus:502,ok:false,error:e.message}));req.setTimeout(20000,()=>{req.destroy();resolve({httpStatus:504,ok:false,error:'NasionalPay timeout'})});req.write(JSON.stringify(payload));req.end()})}
function json(status,obj){return{statusCode:status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'},body:JSON.stringify(obj)}}
