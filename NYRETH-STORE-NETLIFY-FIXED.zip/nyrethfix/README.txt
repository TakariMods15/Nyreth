NYRETH-STORE - NETLIFY FIX + NASIONALPAY QRIS

Upload this whole project to Netlify. The root MUST contain index.html and netlify.toml.

Functions:
/.netlify/functions/create-qris
/.netlify/functions/check-payment

The NasionalPay Store Key is included as a backend fallback for easier setup. For a public production store, set Netlify Environment Variable:
NASIONALPAY_STORE_KEY = your current Store Key
Then rotate the exposed key after testing.

Do NOT delete netlify/functions.
